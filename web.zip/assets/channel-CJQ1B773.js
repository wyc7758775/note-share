import{U as a,C as n}from"./index-BWG40Pme.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
