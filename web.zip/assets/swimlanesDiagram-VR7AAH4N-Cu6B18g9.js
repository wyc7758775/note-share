import{c as r,s as e}from"./flowDiagram-HODETNUW-uG-5K7ym.js";import{_ as a}from"./index-BKGGxlUj.js";import"./transform-CpIVI4vC.js";import"./chunk-5VM5RSS4-q5SfrITO.js";import"./chunk-XXDRQBXY-DKbDkpof.js";import"./chunk-POPQ4Y6H-DjMlKdmJ.js";import"./chunk-F27PBJKO-D01kEY7w.js";import"./purify.es-DBIK8olT.js";import"./channel-W6o543db.js";import"./index-Cb7WgZLz.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,_=r({defaultLayout:"swimlane",styles:m});export{_ as diagram};
