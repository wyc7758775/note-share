import{c as r,s as e}from"./flowDiagram-HODETNUW-Brl_fL9X.js";import{_ as a}from"./index-C_Rv3OIZ.js";import"./transform-CpIVI4vC.js";import"./chunk-5VM5RSS4-Cwvs0Lpx.js";import"./chunk-XXDRQBXY-DDU0UYGJ.js";import"./chunk-POPQ4Y6H-BzAc6Y4k.js";import"./chunk-F27PBJKO-W949ZuaM.js";import"./purify.es-DBIK8olT.js";import"./channel-B0Xhvsli.js";import"./index-C17sYmGI.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,_=r({defaultLayout:"swimlane",styles:m});export{_ as diagram};
