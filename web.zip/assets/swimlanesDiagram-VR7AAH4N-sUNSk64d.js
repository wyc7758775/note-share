import{c as r,s as e}from"./flowDiagram-HODETNUW-EAMkw1Pm.js";import{_ as a}from"./index-BGGx5JiQ.js";import"./transform-CpIVI4vC.js";import"./chunk-5VM5RSS4-DiysrxRv.js";import"./chunk-XXDRQBXY-ByIA-BwL.js";import"./chunk-POPQ4Y6H-C_wlqv11.js";import"./chunk-F27PBJKO-CObSc8aT.js";import"./purify.es-DBIK8olT.js";import"./channel-Cv4Bq0XP.js";import"./index-DRyfLytV.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,_=r({defaultLayout:"swimlane",styles:m});export{_ as diagram};
