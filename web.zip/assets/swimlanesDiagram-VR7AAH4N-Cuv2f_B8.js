import{c as r,s as e}from"./flowDiagram-HODETNUW-CE1bupnQ.js";import{_ as a}from"./index-i22PYRC-.js";import"./transform-CpIVI4vC.js";import"./chunk-5VM5RSS4-C9dy4ZE4.js";import"./chunk-XXDRQBXY-TzQiVD3p.js";import"./chunk-POPQ4Y6H-Bnr-8RzJ.js";import"./chunk-F27PBJKO-BQeFPOez.js";import"./purify.es-DBIK8olT.js";import"./channel-BI1DHfJC.js";import"./index-Bg4OothU.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,_=r({defaultLayout:"swimlane",styles:m});export{_ as diagram};
