import{c as r,s as e}from"./flowDiagram-HODETNUW-B4uqppnr.js";import{_ as a}from"./index-yKTgdaix.js";import"./transform-CpIVI4vC.js";import"./chunk-5VM5RSS4-CzKyNomJ.js";import"./chunk-XXDRQBXY-38Peore1.js";import"./chunk-POPQ4Y6H-CiAp03BH.js";import"./chunk-F27PBJKO-Dhs6bRaA.js";import"./purify.es-DBIK8olT.js";import"./channel-DbAFS9_w.js";import"./index-DzLjxnGu.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,_=r({defaultLayout:"swimlane",styles:m});export{_ as diagram};
