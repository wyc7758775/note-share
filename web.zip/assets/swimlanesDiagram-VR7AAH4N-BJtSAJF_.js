import{c as r,s as e}from"./flowDiagram-HODETNUW-BvqhQ_WA.js";import{_ as a}from"./index-BkCoAncb.js";import"./transform-CpIVI4vC.js";import"./chunk-5VM5RSS4-B5eibpeA.js";import"./chunk-XXDRQBXY-CLSgjVB2.js";import"./chunk-POPQ4Y6H-9lF8DJvn.js";import"./chunk-F27PBJKO-DmR0rX4b.js";import"./purify.es-DBIK8olT.js";import"./channel-2hr89iQj.js";import"./index-C1F52EwB.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,_=r({defaultLayout:"swimlane",styles:m});export{_ as diagram};
