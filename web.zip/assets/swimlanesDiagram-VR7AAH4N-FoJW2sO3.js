import{c as r,s as e}from"./flowDiagram-HODETNUW-DGqtRQXB.js";import{_ as a}from"./index-BWG40Pme.js";import"./transform-CpIVI4vC.js";import"./chunk-5VM5RSS4-XR37ozhR.js";import"./chunk-XXDRQBXY-BInJi5qA.js";import"./chunk-POPQ4Y6H-Cs1ERyYt.js";import"./chunk-F27PBJKO-BRc68TZw.js";import"./purify.es-DBIK8olT.js";import"./channel-CJQ1B773.js";import"./index-DdwYr-Af.js";var o=a(t=>`${e(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),m=o,_=r({defaultLayout:"swimlane",styles:m});export{_ as diagram};
